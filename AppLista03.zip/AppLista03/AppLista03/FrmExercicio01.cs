﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void lblexercicio_Click(object sender, EventArgs e)
        {

        }

        private void btnsoma_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txtn1.Text);
            int n2 = int.Parse(txtn2.Text);
            int n3 = int.Parse(txtn3.Text);

            float resultado;

            resultado = n1 + n3;

            MessageBox.Show("A soma é: " + resultado);
        }

        private void btnmedia_Click(object sender, EventArgs e)
        {
            float n1 = int.Parse(txtn1.Text);
            float n2 = int.Parse(txtn2.Text);
            float n3 = int.Parse(txtn3.Text);

            float resultado;

            resultado = (n1 + n2 + n3) / 3;

            MessageBox.Show("A média é: " + resultado);
        }

        private void btnporcentagem_Click(object sender, EventArgs e)
        {
            float n1 = int.Parse(txtn1.Text);
            float n2 = int.Parse(txtn2.Text);
            float n3 = int.Parse(txtn3.Text);

            float p1, p2, p3;

            p1 = n1 / (n1 + n2 + n3) * 100;
            p2 = n2 / (n1 + n2 + n3) * 100;
            p3 = n3 / (n1 + n2 + n3) * 100;

            MessageBox.Show("Porcentagem do n1 = " + p1);
            MessageBox.Show("Porcentagem do n2 = " + p2);
            MessageBox.Show("Porcentagem do n3 = " + p3);


        }
    }
}
