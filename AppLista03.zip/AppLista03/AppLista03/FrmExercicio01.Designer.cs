﻿namespace AppLista03
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExercicio01));
            this.lblexercicio = new System.Windows.Forms.Label();
            this.txtn1 = new System.Windows.Forms.TextBox();
            this.txtn3 = new System.Windows.Forms.TextBox();
            this.txtn2 = new System.Windows.Forms.TextBox();
            this.lbln1 = new System.Windows.Forms.Label();
            this.lbln2 = new System.Windows.Forms.Label();
            this.lbln3 = new System.Windows.Forms.Label();
            this.btnmedia = new System.Windows.Forms.Button();
            this.btnsoma = new System.Windows.Forms.Button();
            this.btnporcentagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblexercicio
            // 
            this.lblexercicio.AutoSize = true;
            this.lblexercicio.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblexercicio.ForeColor = System.Drawing.Color.White;
            this.lblexercicio.Location = new System.Drawing.Point(302, 9);
            this.lblexercicio.Name = "lblexercicio";
            this.lblexercicio.Size = new System.Drawing.Size(177, 36);
            this.lblexercicio.TabIndex = 0;
            this.lblexercicio.Text = "Exercício 01";
            this.lblexercicio.Click += new System.EventHandler(this.lblexercicio_Click);
            // 
            // txtn1
            // 
            this.txtn1.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtn1.Location = new System.Drawing.Point(50, 134);
            this.txtn1.Name = "txtn1";
            this.txtn1.Size = new System.Drawing.Size(171, 33);
            this.txtn1.TabIndex = 1;
            // 
            // txtn3
            // 
            this.txtn3.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtn3.Location = new System.Drawing.Point(50, 333);
            this.txtn3.Name = "txtn3";
            this.txtn3.Size = new System.Drawing.Size(171, 33);
            this.txtn3.TabIndex = 2;
            // 
            // txtn2
            // 
            this.txtn2.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtn2.Location = new System.Drawing.Point(50, 237);
            this.txtn2.Name = "txtn2";
            this.txtn2.Size = new System.Drawing.Size(171, 33);
            this.txtn2.TabIndex = 3;
            // 
            // lbln1
            // 
            this.lbln1.AutoSize = true;
            this.lbln1.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln1.ForeColor = System.Drawing.Color.White;
            this.lbln1.Location = new System.Drawing.Point(45, 94);
            this.lbln1.Name = "lbln1";
            this.lbln1.Size = new System.Drawing.Size(112, 26);
            this.lbln1.TabIndex = 4;
            this.lbln1.Text = "1° número";
            // 
            // lbln2
            // 
            this.lbln2.AutoSize = true;
            this.lbln2.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln2.ForeColor = System.Drawing.Color.White;
            this.lbln2.Location = new System.Drawing.Point(45, 194);
            this.lbln2.Name = "lbln2";
            this.lbln2.Size = new System.Drawing.Size(112, 26);
            this.lbln2.TabIndex = 5;
            this.lbln2.Text = "2° número";
            // 
            // lbln3
            // 
            this.lbln3.AutoSize = true;
            this.lbln3.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbln3.ForeColor = System.Drawing.Color.White;
            this.lbln3.Location = new System.Drawing.Point(45, 295);
            this.lbln3.Name = "lbln3";
            this.lbln3.Size = new System.Drawing.Size(112, 26);
            this.lbln3.TabIndex = 6;
            this.lbln3.Text = "3° número";
            // 
            // btnmedia
            // 
            this.btnmedia.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmedia.ForeColor = System.Drawing.Color.Black;
            this.btnmedia.Location = new System.Drawing.Point(462, 237);
            this.btnmedia.Name = "btnmedia";
            this.btnmedia.Size = new System.Drawing.Size(127, 41);
            this.btnmedia.TabIndex = 7;
            this.btnmedia.Text = "Média";
            this.btnmedia.UseVisualStyleBackColor = true;
            this.btnmedia.Click += new System.EventHandler(this.btnmedia_Click);
            // 
            // btnsoma
            // 
            this.btnsoma.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsoma.ForeColor = System.Drawing.Color.Black;
            this.btnsoma.Location = new System.Drawing.Point(462, 134);
            this.btnsoma.Name = "btnsoma";
            this.btnsoma.Size = new System.Drawing.Size(127, 41);
            this.btnsoma.TabIndex = 8;
            this.btnsoma.Text = "Soma";
            this.btnsoma.UseVisualStyleBackColor = true;
            this.btnsoma.Click += new System.EventHandler(this.btnsoma_Click);
            // 
            // btnporcentagem
            // 
            this.btnporcentagem.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnporcentagem.ForeColor = System.Drawing.Color.Black;
            this.btnporcentagem.Location = new System.Drawing.Point(462, 333);
            this.btnporcentagem.Name = "btnporcentagem";
            this.btnporcentagem.Size = new System.Drawing.Size(127, 41);
            this.btnporcentagem.TabIndex = 9;
            this.btnporcentagem.Text = "Porcentagem";
            this.btnporcentagem.UseVisualStyleBackColor = true;
            this.btnporcentagem.Click += new System.EventHandler(this.btnporcentagem_Click);
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(186)))), ((int)(((byte)(24)))), ((int)(((byte)(27)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnporcentagem);
            this.Controls.Add(this.btnsoma);
            this.Controls.Add(this.btnmedia);
            this.Controls.Add(this.lbln3);
            this.Controls.Add(this.lbln2);
            this.Controls.Add(this.lbln1);
            this.Controls.Add(this.txtn2);
            this.Controls.Add(this.txtn3);
            this.Controls.Add(this.txtn1);
            this.Controls.Add(this.lblexercicio);
            this.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmExercicio01";
            this.Text = "Exercício 01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblexercicio;
        private System.Windows.Forms.TextBox txtn1;
        private System.Windows.Forms.TextBox txtn3;
        private System.Windows.Forms.TextBox txtn2;
        private System.Windows.Forms.Label lbln1;
        private System.Windows.Forms.Label lbln2;
        private System.Windows.Forms.Label lbln3;
        private System.Windows.Forms.Button btnmedia;
        private System.Windows.Forms.Button btnsoma;
        private System.Windows.Forms.Button btnporcentagem;
    }
}

