﻿namespace AppTestePratico_MateusCampos
{
    partial class FrmQuestao02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao02));
            this.pnlloja = new System.Windows.Forms.Panel();
            this.lblloja = new System.Windows.Forms.Label();
            this.lblpequena = new System.Windows.Forms.Label();
            this.lblmedia = new System.Windows.Forms.Label();
            this.lblgrande = new System.Windows.Forms.Label();
            this.txtpequena = new System.Windows.Forms.TextBox();
            this.txtmedia = new System.Windows.Forms.TextBox();
            this.txtgrande = new System.Windows.Forms.TextBox();
            this.lblpagar = new System.Windows.Forms.Label();
            this.lblresultado = new System.Windows.Forms.Label();
            this.btncomprar = new System.Windows.Forms.Button();
            this.pnlloja.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlloja
            // 
            this.pnlloja.BackColor = System.Drawing.Color.Lime;
            this.pnlloja.Controls.Add(this.lblloja);
            this.pnlloja.Location = new System.Drawing.Point(-1, 0);
            this.pnlloja.Name = "pnlloja";
            this.pnlloja.Size = new System.Drawing.Size(1007, 114);
            this.pnlloja.TabIndex = 0;
            // 
            // lblloja
            // 
            this.lblloja.AutoSize = true;
            this.lblloja.Font = new System.Drawing.Font("Microsoft YaHei", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblloja.Location = new System.Drawing.Point(320, 33);
            this.lblloja.Name = "lblloja";
            this.lblloja.Size = new System.Drawing.Size(364, 50);
            this.lblloja.TabIndex = 0;
            this.lblloja.Text = "LOJA DE CAMISAS";
            // 
            // lblpequena
            // 
            this.lblpequena.AutoSize = true;
            this.lblpequena.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpequena.Location = new System.Drawing.Point(76, 161);
            this.lblpequena.Name = "lblpequena";
            this.lblpequena.Size = new System.Drawing.Size(225, 28);
            this.lblpequena.TabIndex = 1;
            this.lblpequena.Text = "Camisas tamanho P:";
            // 
            // lblmedia
            // 
            this.lblmedia.AutoSize = true;
            this.lblmedia.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedia.Location = new System.Drawing.Point(76, 278);
            this.lblmedia.Name = "lblmedia";
            this.lblmedia.Size = new System.Drawing.Size(233, 28);
            this.lblmedia.TabIndex = 2;
            this.lblmedia.Text = "Camisas tamanho M:";
            // 
            // lblgrande
            // 
            this.lblgrande.AutoSize = true;
            this.lblgrande.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrande.Location = new System.Drawing.Point(76, 397);
            this.lblgrande.Name = "lblgrande";
            this.lblgrande.Size = new System.Drawing.Size(227, 28);
            this.lblgrande.TabIndex = 3;
            this.lblgrande.Text = "Camisas tamanho G:";
            // 
            // txtpequena
            // 
            this.txtpequena.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpequena.Location = new System.Drawing.Point(81, 212);
            this.txtpequena.Name = "txtpequena";
            this.txtpequena.Size = new System.Drawing.Size(220, 35);
            this.txtpequena.TabIndex = 4;
            // 
            // txtmedia
            // 
            this.txtmedia.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmedia.Location = new System.Drawing.Point(81, 330);
            this.txtmedia.Name = "txtmedia";
            this.txtmedia.Size = new System.Drawing.Size(220, 35);
            this.txtmedia.TabIndex = 5;
            // 
            // txtgrande
            // 
            this.txtgrande.Font = new System.Drawing.Font("Microsoft YaHei", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtgrande.Location = new System.Drawing.Point(81, 451);
            this.txtgrande.Name = "txtgrande";
            this.txtgrande.Size = new System.Drawing.Size(220, 35);
            this.txtgrande.TabIndex = 6;
            // 
            // lblpagar
            // 
            this.lblpagar.AutoSize = true;
            this.lblpagar.Font = new System.Drawing.Font("Microsoft YaHei", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpagar.ForeColor = System.Drawing.Color.Lime;
            this.lblpagar.Location = new System.Drawing.Point(347, 525);
            this.lblpagar.Name = "lblpagar";
            this.lblpagar.Size = new System.Drawing.Size(264, 46);
            this.lblpagar.TabIndex = 7;
            this.lblpagar.Text = "Valor a pagar:";
            // 
            // lblresultado
            // 
            this.lblresultado.AutoSize = true;
            this.lblresultado.Font = new System.Drawing.Font("Microsoft YaHei", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblresultado.ForeColor = System.Drawing.Color.Lime;
            this.lblresultado.Location = new System.Drawing.Point(617, 525);
            this.lblresultado.Name = "lblresultado";
            this.lblresultado.Size = new System.Drawing.Size(66, 46);
            this.lblresultado.TabIndex = 8;
            this.lblresultado.Text = "R$";
            // 
            // btncomprar
            // 
            this.btncomprar.BackColor = System.Drawing.Color.Lime;
            this.btncomprar.Font = new System.Drawing.Font("Microsoft YaHei", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncomprar.ForeColor = System.Drawing.Color.White;
            this.btncomprar.Location = new System.Drawing.Point(81, 515);
            this.btncomprar.Name = "btncomprar";
            this.btncomprar.Size = new System.Drawing.Size(220, 53);
            this.btncomprar.TabIndex = 9;
            this.btncomprar.Text = "Comprar";
            this.btncomprar.UseVisualStyleBackColor = false;
            this.btncomprar.Click += new System.EventHandler(this.btncomprar_Click);
            // 
            // FrmQuestao02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1007, 593);
            this.Controls.Add(this.btncomprar);
            this.Controls.Add(this.lblresultado);
            this.Controls.Add(this.lblpagar);
            this.Controls.Add(this.txtgrande);
            this.Controls.Add(this.txtmedia);
            this.Controls.Add(this.txtpequena);
            this.Controls.Add(this.lblgrande);
            this.Controls.Add(this.lblmedia);
            this.Controls.Add(this.lblpequena);
            this.Controls.Add(this.pnlloja);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmQuestao02";
            this.Text = "FrmQuestao02";
            this.pnlloja.ResumeLayout(false);
            this.pnlloja.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlloja;
        private System.Windows.Forms.Label lblloja;
        private System.Windows.Forms.Label lblpequena;
        private System.Windows.Forms.Label lblmedia;
        private System.Windows.Forms.Label lblgrande;
        private System.Windows.Forms.TextBox txtpequena;
        private System.Windows.Forms.TextBox txtmedia;
        private System.Windows.Forms.TextBox txtgrande;
        private System.Windows.Forms.Label lblpagar;
        private System.Windows.Forms.Label lblresultado;
        private System.Windows.Forms.Button btncomprar;
    }
}