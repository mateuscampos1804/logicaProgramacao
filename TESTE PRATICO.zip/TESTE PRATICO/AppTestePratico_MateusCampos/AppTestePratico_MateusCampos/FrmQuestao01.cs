﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_MateusCampos
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void btnpao_Click(object sender, EventArgs e)
        {
            int paes = int.Parse(txtpao.Text);
            int broas = int.Parse(txtbroa.Text);

            float resultado;

            resultado = paes * 0.12f + broas * 1.50f;

            lblvalor.Text = "R$" + resultado;

        }
    }
}
