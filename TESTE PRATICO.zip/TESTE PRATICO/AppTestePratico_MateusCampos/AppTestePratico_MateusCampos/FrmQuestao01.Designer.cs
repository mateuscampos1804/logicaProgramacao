﻿namespace AppTestePratico_MateusCampos
{
    partial class FrmQuestao01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuestao01));
            this.lblpao = new System.Windows.Forms.Label();
            this.txtpao = new System.Windows.Forms.TextBox();
            this.lblbroa = new System.Windows.Forms.Label();
            this.txtbroa = new System.Windows.Forms.TextBox();
            this.lblpadaria = new System.Windows.Forms.Label();
            this.btnpao = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblvalor = new System.Windows.Forms.Label();
            this.lblpagar = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblpao
            // 
            this.lblpao.AutoSize = true;
            this.lblpao.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpao.Location = new System.Drawing.Point(59, 126);
            this.lblpao.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpao.Name = "lblpao";
            this.lblpao.Size = new System.Drawing.Size(210, 26);
            this.lblpao.TabIndex = 0;
            this.lblpao.Text = "Quantidade de pães:";
            // 
            // txtpao
            // 
            this.txtpao.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpao.Location = new System.Drawing.Point(64, 178);
            this.txtpao.Margin = new System.Windows.Forms.Padding(4);
            this.txtpao.Name = "txtpao";
            this.txtpao.Size = new System.Drawing.Size(205, 33);
            this.txtpao.TabIndex = 1;
            // 
            // lblbroa
            // 
            this.lblbroa.AutoSize = true;
            this.lblbroa.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbroa.Location = new System.Drawing.Point(59, 237);
            this.lblbroa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblbroa.Name = "lblbroa";
            this.lblbroa.Size = new System.Drawing.Size(210, 26);
            this.lblbroa.TabIndex = 2;
            this.lblbroa.Text = "Quantidade de broa:";
            // 
            // txtbroa
            // 
            this.txtbroa.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbroa.Location = new System.Drawing.Point(64, 285);
            this.txtbroa.Margin = new System.Windows.Forms.Padding(4);
            this.txtbroa.Name = "txtbroa";
            this.txtbroa.Size = new System.Drawing.Size(205, 33);
            this.txtbroa.TabIndex = 3;
            // 
            // lblpadaria
            // 
            this.lblpadaria.AutoSize = true;
            this.lblpadaria.Font = new System.Drawing.Font("Microsoft YaHei", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpadaria.ForeColor = System.Drawing.Color.White;
            this.lblpadaria.Location = new System.Drawing.Point(405, 21);
            this.lblpadaria.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpadaria.Name = "lblpadaria";
            this.lblpadaria.Size = new System.Drawing.Size(255, 64);
            this.lblpadaria.TabIndex = 4;
            this.lblpadaria.Text = "PADARIA";
            // 
            // btnpao
            // 
            this.btnpao.BackColor = System.Drawing.Color.Black;
            this.btnpao.Font = new System.Drawing.Font("Microsoft YaHei", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnpao.ForeColor = System.Drawing.Color.White;
            this.btnpao.Location = new System.Drawing.Point(64, 354);
            this.btnpao.Margin = new System.Windows.Forms.Padding(4);
            this.btnpao.Name = "btnpao";
            this.btnpao.Size = new System.Drawing.Size(205, 65);
            this.btnpao.TabIndex = 5;
            this.btnpao.Text = "Comprar pão";
            this.btnpao.UseVisualStyleBackColor = false;
            this.btnpao.Click += new System.EventHandler(this.btnpao_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Controls.Add(this.lblpadaria);
            this.panel1.Location = new System.Drawing.Point(-3, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1074, 114);
            this.panel1.TabIndex = 6;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.lblvalor);
            this.panel2.Controls.Add(this.lblpagar);
            this.panel2.Location = new System.Drawing.Point(-3, 447);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1074, 130);
            this.panel2.TabIndex = 7;
            // 
            // lblvalor
            // 
            this.lblvalor.AutoSize = true;
            this.lblvalor.Font = new System.Drawing.Font("Microsoft YaHei", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblvalor.Location = new System.Drawing.Point(560, 42);
            this.lblvalor.Name = "lblvalor";
            this.lblvalor.Size = new System.Drawing.Size(68, 39);
            this.lblvalor.TabIndex = 1;
            this.lblvalor.Text = "R$-";
            // 
            // lblpagar
            // 
            this.lblpagar.AutoSize = true;
            this.lblpagar.Font = new System.Drawing.Font("Microsoft YaHei", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpagar.Location = new System.Drawing.Point(332, 42);
            this.lblpagar.Name = "lblpagar";
            this.lblpagar.Size = new System.Drawing.Size(222, 39);
            this.lblpagar.TabIndex = 0;
            this.lblpagar.Text = "Valor a pagar:";
            // 
            // FrmQuestao01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1069, 576);
            this.Controls.Add(this.btnpao);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtbroa);
            this.Controls.Add(this.lblbroa);
            this.Controls.Add(this.txtpao);
            this.Controls.Add(this.lblpao);
            this.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmQuestao01";
            this.Text = "Padaria";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpao;
        private System.Windows.Forms.TextBox txtpao;
        private System.Windows.Forms.Label lblbroa;
        private System.Windows.Forms.TextBox txtbroa;
        private System.Windows.Forms.Label lblpadaria;
        private System.Windows.Forms.Button btnpao;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblvalor;
        private System.Windows.Forms.Label lblpagar;
    }
}

