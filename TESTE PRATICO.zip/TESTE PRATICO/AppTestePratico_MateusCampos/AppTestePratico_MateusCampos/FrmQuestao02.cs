﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppTestePratico_MateusCampos
{
    public partial class FrmQuestao02 : Form
    {
        public FrmQuestao02()
        {
            InitializeComponent();
        }

        private void btncomprar_Click(object sender, EventArgs e)
        {
            int camisap = int.Parse(txtpequena.Text);
            int camisam = int.Parse(txtmedia.Text);
            int camisag = int.Parse(txtgrande.Text);

            float resultado;

            resultado = camisap * 12 + camisam * 14 + camisag * 22;

            lblresultado.Text = "R$" + resultado; 


        }
    }
}
